function Invoke-CommandFunction
{
    param([scriptblock]$command)
    & $command
}

function Create-CommandFunction
{
    param([string]$payload)
    return {
        Write-Host "Commande ex�cut�e avec la charge utile : $payload"
    }
}

# Cr�ation et invocation de la commande
$commandFunction = Create-CommandFunction -payload "Donn�es de test"
Invoke-CommandFunction -command $commandFunction
