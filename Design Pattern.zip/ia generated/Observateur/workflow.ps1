workflow Notify-Observers
{
    InlineScript
    {
        function Add-Observer
        {
            param([scriptblock]$callback)
            $script:observers += $callback
        }

        function Notify
        {
            $script:observers | ForEach-Object { $_.Invoke() }
        }

        $script:observers = @()

        Add-Observer { Write-Output "Premier observateur notifié !" }
        Add-Observer { Write-Output "Deuxième observateur notifié !" }

        Notify
    }
}

# Exécution du workflow
Notify-Observers
