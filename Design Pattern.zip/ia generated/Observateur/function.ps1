function Add-Observer
{
    param([scriptblock]$callback)
    $script:observers += $callback
}

function Notify-Observers
{
    $script:observers | ForEach-Object { $_.Invoke() }
}

function Initialize-Observers
{
    $script:observers = @()
}

Initialize-Observers
Add-Observer { Write-Host "Premier observateur notifié !" }
Add-Observer { Write-Host "Deuxième observateur notifié !" }

# Lorsque cet appel est fait, tous les observateurs sont notifiés.
Notify-Observers
