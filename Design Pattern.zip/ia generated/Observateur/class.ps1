class Subject
{
    [System.Collections.ArrayList]$observers = @()

    [void] Attach([scriptblock]$observer)
    {
        $this.observers.Add($observer)
    }

    [void] Detach([scriptblock]$observer)
    {
        $this.observers.Remove($observer)
    }

    [void] Notify()
    {
        foreach ($observer in $this.observers)
        {
            $observer.Invoke()
        }
    }
}

class Observer
{
    [string]$name

    Observer([string]$name)
    {
        $this.name = $name
    }

    [scriptblock] Update()
    {
        return {
            Write-Host "$($this.name) a �t� notifi� !"
        }
    }
}

$subject = [Subject]::new()
$observer1 = [Observer]::new("Observateur 1")
$observer2 = [Observer]::new("Observateur 2")

$subject.Attach($observer1.Update())
$subject.Attach($observer2.Update())

# Lorsque cet appel est fait, tous les observateurs sont notifi�s.
$subject.Notify()
