﻿function Creer-Pile 
{
    $stk = New-Object 'System.Collections.Generic.List[object]'
    return ,$stk
}

function Empiler 
{
    param 
    (
        [System.Collections.Generic.List[object]] $stk,
        [object] $t
    )
    $stk.Add($t)
}

# Utilisation des fonctions
$pile = Creer-Pile
Empiler -stk $pile -t 4
