﻿# Classe Pile utilisant la délégation
class Pile
{
    [System.Collections.Generic.List[object]] $stk

    Pile()
    {
        $this.stk = New-Object 'System.Collections.Generic.List[object]'
    }

    [void] Empiler([object] $t)
    {
        $this.stk.Add($t)
    }
}

# Classe Client utilisant la classe Pile
class Client
{
    [void] Main()
    {
        $p = [Pile]::new()
        $p.Empiler(4)
    }
}
