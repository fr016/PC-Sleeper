function Publish-Message
{
    param([string]$message, [string[]]$subscribers)
    foreach ($subscriber in $subscribers)
    {
       Write-Host "Notifying ${subscriber}: $message"
    }
}

function Subscribe
{
    param([string]$subscriber, [ref]$subscribers)
    $subscribers.Value += $subscriber
}

function Unsubscribe
{
    param([string]$subscriber, [ref]$subscribers)
    $subscribers.Value = $subscribers.Value -ne $subscriber
}

# Utilisation
$subscribers = @()
Subscribe -subscriber "Subscriber1" -subscribers ([ref]$subscribers)
Subscribe -subscriber "Subscriber2" -subscribers ([ref]$subscribers)
Publish-Message -message "Event occurred" -subscribers $subscribers
Unsubscribe -subscriber "Subscriber1" -subscribers ([ref]$subscribers)
Publish-Message -message "Another event occurred" -subscribers $subscribers
