class Publisher
{
    hidden [System.Collections.ArrayList]$subscribers = @()

    [void] AddSubscriber([string]$subscriber)
    {
        $this.subscribers.Add($subscriber)
    }

    [void] RemoveSubscriber([string]$subscriber)
    {
        $this.subscribers.Remove($subscriber)
    }

    [void] NotifySubscribers([string]$message)
    {
        foreach ($subscriber in $this.subscribers)
        {
            Write-Host "Notifying ${subscriber}: $message"
        }
    }
}

# Utilisation
$publisher = [Publisher]::new()
$publisher.AddSubscriber("Subscriber1")
$publisher.AddSubscriber("Subscriber2")
$publisher.NotifySubscribers("Event occurred")
$publisher.RemoveSubscriber("Subscriber1")
$publisher.NotifySubscribers("Another event occurred")
