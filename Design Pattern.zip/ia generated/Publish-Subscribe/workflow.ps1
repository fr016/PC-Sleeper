workflow Invoke-PublisherWorkflow
{
    param([string]$message, [string[]]$subscribers)

    InlineScript
    {
        foreach ($subscriber in $using:subscribers)
        {
            Write-Host "Notifying ${subscriber}: $message"
        }
    }
}

# Utilisation
$subscribers = @("Subscriber1", "Subscriber2")
Invoke-PublisherWorkflow -message "Event occurred" -subscribers $subscribers
