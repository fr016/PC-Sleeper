workflow Invoke-StateWorkflow
{
    param([string]$initialState)

    InlineScript
    {
        $context = @{}
        $context.State = $using:initialState

        function Set-State($state)
        {
            $context.State = $state
        }

        function Get-State()
        {
            return $context.State
        }

        function Do-Action()
        {
            switch ($context.State)
            {
                "Start" { Write-Output "Player is in start state"; Set-State "Start State" }
                "Stop" { Write-Output "Player is in stop state"; Set-State "Stop State" }
            }
        }

        Do-Action
        return Get-State
    }
}

$startState = Invoke-StateWorkflow -initialState "Start"
Write-Host "State after start action:" $startState

$stopState = Invoke-StateWorkflow -initialState "Stop"
Write-Host "State after stop action:" $stopState
