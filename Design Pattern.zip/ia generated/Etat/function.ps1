function Set-State($context, $state)
{
    $context.State = $state
}

function Get-State($context)
{
    return $context.State
}

function Do-Action($context)
{
    $state = Get-State $context
    $state.Invoke($context)
}

$context = @{}
$context.State = { Write-Host "Player is in start state"; Set-State $context "Start State" }
Do-Action $context
Write-Host (Get-State $context)

$context.State = { Write-Host "Player is in stop state"; Set-State $context "Stop State" }
Do-Action $context
Write-Host (Get-State $context)
