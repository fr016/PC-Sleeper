class Context
{
    [string] $State

    Context()
    {
        $this.State = $null
    }

    [void] SetState([string] $state)
    {
        $this.State = $state
    }

    [string] GetState()
    {
        return $this.State
    }

    [void] DoAction()
    {
        switch ($this.State)
        {
            "Start" { Write-Host "Player is in start state"; $this.SetState("Start State") }
            "Stop" { Write-Host "Player is in stop state"; $this.SetState("Stop State") }
        }
    }
}

$context = [Context]::new()
$context.SetState("Start")
$context.DoAction()
Write-Host $context.GetState()

$context.SetState("Stop")
$context.DoAction()
Write-Host $context.GetState()
