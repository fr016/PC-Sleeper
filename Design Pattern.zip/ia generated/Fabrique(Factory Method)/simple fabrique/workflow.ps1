workflow Invoke-ShapeDrawWorkflow
{
    param([string] $shapeType)

    InlineScript
    {
        function Draw-Shape
        {
            param([string] $shapeType)
            switch ($shapeType)
            {
                "CIRCLE" { Write-Output "Inside Circle::draw() method." }
                "RECTANGLE" { Write-Output "Inside Rectangle::draw() method." }
                "SQUARE" { Write-Output "Inside Square::draw() method." }
                default { Write-Output "Invalid shape type." }
            }
        }

        Draw-Shape -shapeType $using:shapeType
    }
}

# Utilisation du workflow pour dessiner les formes
Invoke-ShapeDrawWorkflow -shapeType "CIRCLE"
Invoke-ShapeDrawWorkflow -shapeType "RECTANGLE"
Invoke-ShapeDrawWorkflow -shapeType "SQUARE"
