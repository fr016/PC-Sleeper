function Draw-Shape($shapeType)
{
    switch ($shapeType)
    {
        "CIRCLE" { Write-Host "Inside Circle::draw() method." }
        "RECTANGLE" { Write-Host "Inside Rectangle::draw() method." }
        "SQUARE" { Write-Host "Inside Square::draw() method." }
        default { Write-Host "Invalid shape type." }
    }
}

# Utilisation de la fonction pour dessiner les formes
Draw-Shape -shapeType "CIRCLE"
Draw-Shape -shapeType "RECTANGLE"
Draw-Shape -shapeType "SQUARE"
