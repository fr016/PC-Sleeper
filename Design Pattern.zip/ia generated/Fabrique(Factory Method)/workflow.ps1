workflow Invoke-ProductCreationWorkflow
{
    param([string] $productType)

    InlineScript
    {
        function Create-Product
        {
            param([string] $productType)
            switch ($productType)
            {
                "ProductA" { return @{ Name = "Product A"; Type = "A" } }
                "ProductB" { return @{ Name = "Product B"; Type = "B" } }
                default { return $null }
            }
        }

        $product = Create-Product -productType $using:productType
        Write-Output $product
    }
}

# Cr�ation de produits en utilisant le workflow
$productA = Invoke-ProductCreationWorkflow -productType "ProductA"
$productB = Invoke-ProductCreationWorkflow -productType "ProductB"
