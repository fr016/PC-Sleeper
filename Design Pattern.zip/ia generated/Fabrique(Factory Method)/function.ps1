function Create-Product($productType)
{
    switch ($productType)
    {
        "ProductA" { return New-Object PSObject -Property @{ Name = "Product A"; Type = "A" } }
        "ProductB" { return New-Object PSObject -Property @{ Name = "Product B"; Type = "B" } }
        default { return $null }
    }
}

# Utilisation de la fonction pour cr�er des produits
$productA = Create-Product -productType "ProductA"
$productB = Create-Product -productType "ProductB"
