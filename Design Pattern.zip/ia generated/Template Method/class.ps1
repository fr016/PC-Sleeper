class GameAI
{
    [void] CollectResources()
    {
        # Code pour collecter les ressources
    }

    [void] BuildStructures()
    {
        # Code pour construire des structures
    }

    [void] BuildUnits()
    {
        # Code pour construire des unit�s
    }

    [void] Attack()
    {
        # Code pour attaquer
    }

    [void] Turn()
    {
        $this.CollectResources()
        $this.BuildStructures()
        $this.BuildUnits()
        $this.Attack()
    }
}

class OrcsAI : GameAI
{
    [void] BuildStructures()
    {
        # Code sp�cifique aux Orcs pour construire des structures
    }

    [void] BuildUnits()
    {
        # Code sp�cifique aux Orcs pour construire des unit�s
    }
}

# Utilisation
$gameAI = [OrcsAI]::new()
$gameAI.Turn()
