class Personne {
    [int]$Id
    [string]$Nom
    [string]$Adresse

    Personne([int]$id, [string]$nom) {
        $this.Id = $id
        $this.Nom = $nom
    }

    [void]SetAdresse([string]$adresse) {
        $this.Adresse = $adresse
    }

    [void]Afficher() {
        Write-Host "Id: $($this.Id), Nom: $($this.Nom), Adresse: $($this.Adresse)"
    }
}

# Cr�ation d'une personne et injection de l'adresse via setter
$personne = [Personne]::new(1, "John Doe")
$personne.SetAdresse("123 Main St")
$personne.Afficher()
