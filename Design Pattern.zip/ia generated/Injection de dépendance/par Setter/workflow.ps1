workflow Invoke-PersonneCreation {
    param (
        [int]$id,
        [string]$nom,
        [string]$adresse
    )

    InlineScript {
        function New-Personne {
            param (
                [int]$id,
                [string]$nom
            )
            $personne = @{}
            $personne.Id = $id
            $personne.Nom = $nom
            return $personne
        }

        function Set-Adresse {
            param (
                [ref]$personne,
                [string]$adresse
            )
            $personne.Value.Adresse = $adresse
        }

        function Show-Personne {
            param ([hashtable]$personne)
            Write-Host "Id: $($personne.Id), Nom: $($personne.Nom), Adresse: $($personne.Adresse)"
        }

        $personne = New-Personne -id $using:id -nom $using:nom
        Set-Adresse -personne ([ref]$personne) -adresse $using:adresse
        Show-Personne -personne $personne
    }
}

# Cr�ation d'une personne et injection de l'adresse via setter en utilisant le workflow
Invoke-PersonneCreation -id 1 -nom "John Doe" -adresse "123 Main St"
