function New-Personne {
    param (
        [int]$id,
        [string]$nom
    )
    $personne = @{}
    $personne.Id = $id
    $personne.Nom = $nom
    return $personne
}

function Set-Adresse {
    param (
        [ref]$personne,
        [string]$adresse
    )
    $personne.Value.Adresse = $adresse
}

function Show-Personne {
    param ([hashtable]$personne)
    Write-Host "Id: $($personne.Id), Nom: $($personne.Nom), Adresse: $($personne.Adresse)"
}

# Cr�ation d'une personne et injection de l'adresse via setter
$personne = New-Personne -id 1 -nom "John Doe"
Set-Adresse -personne ([ref]$personne) -adresse "123 Main St"
Show-Personne -personne $personne
