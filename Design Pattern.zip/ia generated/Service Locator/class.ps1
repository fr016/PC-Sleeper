class ServiceLocator
{
    hidden [hashtable]$services = @{}

    [void] RegisterService([string]$serviceName, [scriptblock]$serviceInstance)
    {
        $this.services[$serviceName] = $serviceInstance
    }

    [object] GetService([string]$serviceName)
    {
        return $this.services[$serviceName].Invoke()
    }
}

# Utilisation
$serviceLocator = [ServiceLocator]::new()
$serviceLocator.RegisterService("ArticleRepository", { return New-Object Object })
$serviceLocator.RegisterService("StockRepository", { return New-Object Object })
$serviceLocator.RegisterService("ArticleController", { return New-Object Object })

$articleRepository = $serviceLocator.GetService("ArticleRepository")
$stockRepository = $serviceLocator.GetService("StockRepository")
$articleController = $serviceLocator.GetService("ArticleController")
