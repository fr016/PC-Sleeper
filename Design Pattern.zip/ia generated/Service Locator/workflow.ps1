workflow Invoke-ServiceLocatorWorkflow
{
    InlineScript
    {
        # D�finition des fonctions du Service Locator
        function Register-Service
        {
            param(
                [string]$serviceName,
                [scriptblock]$serviceInstance
            )
            Set-Variable -Name $serviceName -Value $serviceInstance -Scope Global
        }

        function Get-Service
        {
            param([string]$serviceName)
            return (Get-Variable -Name $serviceName -Scope Global).Value.Invoke()
        }

        # Enregistrement des services
        Register-Service -serviceName "ArticleRepository" -serviceInstance { return New-Object Object }
        Register-Service -serviceName "StockRepository" -serviceInstance { return New-Object Object }
        Register-Service -serviceName "ArticleController" -serviceInstance { return New-Object Object }

        # R�cup�ration des services
        $articleRepository = Get-Service -serviceName "ArticleRepository"
        $stockRepository = Get-Service -serviceName "StockRepository"
        $articleController = Get-Service -serviceName "ArticleController"
    }
}

# Utilisation du workflow
Invoke-ServiceLocatorWorkflow
