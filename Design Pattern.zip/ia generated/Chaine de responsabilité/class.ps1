# Classe de base pour le gestionnaire
class Handler
{
    [Handler] $Successor

    # Constructeur par d�faut
    Handler() { }

    # Constructeur avec successeur
    Handler([Handler] $successor)
    {
        $this.Successor = $successor
    }

    [void] HandleRequest([string] $request)
    {
        if ($this.Successor -ne $null)
        {
            $this.Successor.HandleRequest($request)
        }
    }
}

# Gestionnaire concret A
class ConcreteHandlerA : Handler
{
    # Appel du constructeur de la classe de base avec successeur
    ConcreteHandlerA([Handler] $successor) : base($successor) { }

    [void] HandleRequest([string] $request)
    {
        if ($request -eq "A")
        {
            Write-Host "ConcreteHandlerA a g�r� la demande."
        }
        elseif ($this.Successor -ne $null)
        {
            $this.Successor.HandleRequest($request)
        }
    }
}

# Gestionnaire concret B
class ConcreteHandlerB : Handler
{
    # Appel du constructeur de la classe de base avec successeur
    ConcreteHandlerB([Handler] $successor) : base($successor) { }

    [void] HandleRequest([string] $request)
    {
        if ($request -eq "B")
        {
            Write-Host "ConcreteHandlerB a g�r� la demande."
        }
        elseif ($this.Successor -ne $null)
        {
            $this.Successor.HandleRequest($request)
        }
    }
}

# Configuration de la cha�ne
$handlerA = [ConcreteHandlerA]::new($null)
$handlerB = [ConcreteHandlerB]::new($handlerA)

# D�marrage de la cha�ne
$handlerB.HandleRequest("A") # Affiche : ConcreteHandlerA a g�r� la demande.
$handlerB.HandleRequest("B") # Affiche : ConcreteHandlerB a g�r� la demande.
