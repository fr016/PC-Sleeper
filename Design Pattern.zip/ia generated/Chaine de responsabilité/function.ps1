function HandlerA
{
    param([string]$request, [scriptblock]$successor)

    if ($request -eq "A")
    {
        Write-Host "HandlerA a g�r� la demande."
    }
    elseif ($successor -ne $null)
    {
        &$successor $request
    }
}

function HandlerB
{
    param([string]$request)

    $successor = { HandlerA $args[0] $null }

    if ($request -eq "B")
    {
        Write-Host "HandlerB a g�r� la demande."
    }
    else
    {
        &$successor $request
    }
}

# D�marrage de la cha�ne
HandlerB "A" # Affiche : HandlerA a g�r� la demande.
