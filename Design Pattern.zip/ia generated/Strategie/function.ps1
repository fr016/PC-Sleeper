
# Fonction qui calcule le carré d'un nombre
function Square($x)
{
    return $x * $x
}

# Fonction qui calcule le cube d'un nombre
function Cube($x)
{
    return $x * $x * $x
}

# Variable qui contient la référence à la stratégie actuelle (par défaut, c'est la fonction Square)
$currentStrategy = Square

# Fonction qui exécute la stratégie actuelle
function ExecuteStrategy($x)
{
    &$currentStrategy $x
}

# Exemple d'utilisation de la stratégie actuelle
ExecuteStrategy 5  # Retourne 25 (5^2)

# Changement de stratégie
$currentStrategy = Cube

# Exemple d'utilisation de la nouvelle stratégie
ExecuteStrategy 5  # Retourne 125 (5^3)