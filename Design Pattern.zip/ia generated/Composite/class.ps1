# Classe de base pour les composants
class Composant
{
    [int] $Poids

    Composant([int] $poids)
    {
        $this.Poids = $poids
    }

    [int] GetPoids()
    {
        return $this.Poids
    }
}

# Classe d�riv�e pour la remorque
class Remorque : Composant
{
    Remorque([int] $poids) : base($poids)
    {
    }
}

# Classe d�riv�e pour le tracteur
class Tracteur : Composant
{
    Tracteur([int] $poids) : base($poids)
    {
    }
}

# Classe composite pour le camion
class CamionComposite
{
    [System.Collections.ArrayList]$Children

    CamionComposite()
    {
        $this.Children = [System.Collections.ArrayList]::new()
    }

    [void] Add($composant)
    {
        $this.Children.Add($composant)
    }

    [void] Remove($composant)
    {
        $this.Children.Remove($composant)
    }

    [int] GetPoids()
    {
        $poidsTotal = 0
        foreach ($composant in $this.Children)
        {
            $poidsTotal += $composant.GetPoids()
        }
        return $poidsTotal
    }
}

# Cr�ation des composants et calcul du poids total
$remorque = [Remorque]::new(11)
$tracteur = [Tracteur]::new(8)
$semiRemorque = [CamionComposite]::new()

$semiRemorque.Add($remorque)
$semiRemorque.Add($tracteur)

Write-Host "Le poids de ma remorque est:" $remorque.GetPoids() "tonnes"
Write-Host "Le poids de mon tracteur est:" $tracteur.GetPoids() "tonnes"
Write-Host "Le poids de mon semi-remorque est:" $semiRemorque.GetPoids() "tonnes"
