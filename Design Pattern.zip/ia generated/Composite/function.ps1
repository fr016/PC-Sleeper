function Get-Poids($composant)
{
    return $composant.Poids
}

function Create-Remorque($poids)
{
    return @{ Poids = $poids; GetType = { "Remorque" } }
}

function Create-Tracteur($poids)
{
    return @{ Poids = $poids; GetType = { "Tracteur" } }
}

function Add-Composant($composite, $composant)
{
    $composite.Children += $composant
}

function Remove-Composant($composite, $composant)
{
    $composite.Children = $composite.Children | Where-Object { $_ -ne $composant }
}

function Get-CompositePoids($composite)
{
    $poidsTotal = 0
    foreach ($composant in $composite.Children)
    {
        $poidsTotal += Get-Poids $composant
    }
    return $poidsTotal
}

# Utilisation des fonctions pour cr�er un semi-remorque
$remorque = Create-Remorque 11
$tracteur = Create-Tracteur 8
$semiRemorque = @{ Children = @() }

Add-Composant $semiRemorque $remorque
Add-Composant $semiRemorque $tracteur

Write-Host "Le poids de ma remorque est:" (Get-Poids $remorque) "tonnes"
Write-Host "Le poids de mon tracteur est:" (Get-Poids $tracteur) "tonnes"
Write-Host "Le poids de mon semi-remorque est:" (Get-CompositePoids $semiRemorque) "tonnes"
