workflow Get-CompositePoidsWorkflow
{
    param([object[]]$composants)

    InlineScript
    {
        $poidsTotal = 0
        foreach ($composant in $using:composants)
        {
            $poidsTotal += $composant.Poids
        }
        Write-Output $poidsTotal
    }
}

# Cr�ation des composants et calcul du poids total en workflow
$remorque = @{ Poids = 11 }
$tracteur = @{ Poids = 8 }
$composants = @($remorque, $tracteur)

$poidsTotal = Get-CompositePoidsWorkflow -composants $composants
Write-Host "Le poids total du semi-remorque est:" $poidsTotal "tonnes"
