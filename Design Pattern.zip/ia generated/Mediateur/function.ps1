function Show-Message
{
    param([string]$user, [string]$message)
    $timeStamp = Get-Date -Format "ddd MMM dd HH:mm:ss yyyy"
    Write-Host "$timeStamp [$user] : $message"
}

function Send-Message
{
    param([string]$user, [string]$message)
    Show-Message -user $user -message $message
}

# Utilisation
Send-Message -user "Robert" -message "Hi! John!"
Send-Message -user "John" -message "Hello! Robert!"
