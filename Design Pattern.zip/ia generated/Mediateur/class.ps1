class ChatRoom
{
    static [void] ShowMessage([string]$user, [string]$message)
    {
        $timeStamp = Get-Date -Format "ddd MMM dd HH:mm:ss yyyy"
        Write-Host "$timeStamp [$user] : $message"
    }
}

class User
{
    [string] $Name

    User([string]$name)
    {
        $this.Name = $name
    }

    [void] SendMessage([string]$message)
    {
        [ChatRoom]::ShowMessage($this.Name, $message)
    }
}

# Utilisation
$robert = [User]::new("Robert")
$john = [User]::new("John")

$robert.SendMessage("Hi! John!")
$john.SendMessage("Hello! Robert!")
