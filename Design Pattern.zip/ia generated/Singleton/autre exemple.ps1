cls
<#
class utilitaire de connexion a une base de donn�e
#>

class BDConnexion
{
     $login
     $mdp
	static [BDConnexion]$instance=[BDConnexion]::new() 
	
	Hidden BDConnexion()
    {
       
    }
	
      etablirConnexion ($login, $mdp)
    {
        $this.login=$login
        $this.mdp=$mdp
    }
	
     [BDConnexion] static getInstance()
	{
        return [BDConnexion]::instance
	}
}
  
  
  $a=[BDConnexion]::getInstance()
  
  $a.etablirConnexion("MonsieurT", 'm�t2pA$$')

    $b=[BDConnexion]::getInstance()

    $b

  



 