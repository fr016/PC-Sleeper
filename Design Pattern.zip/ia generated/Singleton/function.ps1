function Singleton
{
    $script:instance = $null

    if (-not $script:instance)
    {
        $script:instance = New-Object PSObject -Property @{
            Message = "Je suis unique."
        }
    }

    return $script:instance
}

$instance1 = Singleton
$instance2 = Singleton

$instance1.Message # Affiche : Je suis unique.
$instance2.Message # Affiche : Je suis unique.

$instance1.Message = "Changement de message."

$instance1.Message # Affiche : Changement de message.
$instance2.Message # Affiche : Changement de message.
