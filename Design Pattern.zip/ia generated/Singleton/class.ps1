﻿cls
class Arbitre
{
    $nom="Jean"
	static [Arbitre]$instance=[Arbitre]::new() 
	
	Hidden Arbitre()
    {
       
    }
	
	
     [Arbitre] static getInstance()
	{
	    return [Arbitre]::instance
	}
}
  
  
  $a=[Arbitre]::getInstance()
  $a.nom="delaFontaine"
  $a
  $b=[Arbitre]::getInstance()
  $b