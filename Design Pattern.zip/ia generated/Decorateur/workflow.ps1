workflow Decorate-DessertWorkflow
{
    param([string]$description, [double]$price, [string[]]$ingredients)

    InlineScript
    {
        function Create-Dessert
        {
            param([string]$description, [double]$price)
            return @{ Description = $description; Price = $price }
        }

        function Add-Ingredient
        {
            param([hashtable]$dessert, [string]$ingredient)
            switch ($ingredient)
            {
                "chocolat" { $dessert.Description += ", chocolat"; $dessert.Price += 0.20 }
                "chantilly" { $dessert.Description += ", chantilly"; $dessert.Price += 0.50 }
            }
        }

        # Cr�ation du dessert
        $dessert = Create-Dessert -description $using:description -price $using:price

        # Ajout des ingr�dients
        foreach ($ingredient in $using:ingredients)
        {
            Add-Ingredient -dessert $dessert -ingredient $ingredient
        }

        Write-Output $dessert
    }
}

# D�coration des desserts en workflow
$crepe = Decorate-DessertWorkflow -description "Cr�pe" -price 1.50 -ingredients @("chocolat", "chantilly")
$gaufre = Decorate-DessertWorkflow -description "Gaufre" -price 1.80 -ingredients @("chocolat")

# Affichage
Write-Host "Description de la cr�pe :" $crepe.Description
Write-Host "Prix de la cr�pe :" $crepe.Price "�"
Write-Host "Description de la gaufre :" $gaufre.Description
Write-Host "Prix de la gaufre :" $gaufre.Price "�"
