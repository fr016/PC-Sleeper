function Get-Description($dessert)
{
    return $dessert.Description
}

function Get-Price($dessert)
{
    return $dessert.Price
}

function Create-Dessert($description, $price)
{
    return @{ Description = $description; Price = $price }
}

function Add-Chocolate($dessert)
{
    $dessert.Description += ", chocolat"
    $dessert.Price += 0.20
}

function Add-Chantilly($dessert)
{
    $dessert.Description += ", chantilly"
    $dessert.Price += 0.50
}

# Cr�ation des desserts
$crepe = Create-Dessert "Cr�pe" 1.50
$gaufre = Create-Dessert "Gaufre" 1.80

# Ajout des ingr�dients
Add-Chocolate $crepe
Add-Chantilly $crepe
Add-Chocolate $gaufre

# Affichage
Write-Host "Description de la cr�pe :" (Get-Description $crepe)
Write-Host "Prix de la cr�pe :" (Get-Price $crepe) "�"
Write-Host "Description de la gaufre :" (Get-Description $gaufre)
Write-Host "Prix de la gaufre :" (Get-Price $gaufre) "�"
