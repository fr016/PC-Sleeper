class Dessert
{
    [string] $Description
    [double] $Price

    Dessert([string] $description, [double] $price)
    {
        $this.Description = $description
        $this.Price = $price
    }

    [string] GetDescription()
    {
        return $this.Description
    }

    [double] GetPrice()
    {
        return $this.Price
    }
}

class ChocolateDecorator : Dessert
{
    ChocolateDecorator([Dessert] $dessert) : base($dessert.GetDescription() + ", chocolat", $dessert.GetPrice() + 0.20)
    {
    }
}

class ChantillyDecorator : Dessert
{
    ChantillyDecorator([Dessert] $dessert) : base($dessert.GetDescription() + ", chantilly", $dessert.GetPrice() + 0.50)
    {
    }
}

# Cr�ation des desserts
$crepe = [Dessert]::new("Cr�pe", 1.50)
$gaufre = [Dessert]::new("Gaufre", 1.80)

# D�coration des desserts
$crepe = [ChocolateDecorator]::new($crepe)
$crepe = [ChantillyDecorator]::new($crepe)
$gaufre = [ChocolateDecorator]::new($gaufre)

# Affichage
Write-Host "Description de la cr�pe :" $crepe.GetDescription()
Write-Host "Prix de la cr�pe :" $crepe.GetPrice() "�"
Write-Host "Description de la gaufre :" $gaufre.GetDescription()
Write-Host "Prix de la gaufre :" $gaufre.GetPrice() "�"
