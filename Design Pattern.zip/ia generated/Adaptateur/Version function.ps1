﻿# Fonction pour afficher les informations d'un client
function Afficher-Client
{
    param (
        [string]$nom
    )
    Write-Host "Nom du client : $nom"
}

# Fonction pour afficher les informations d'un employé
function Afficher-Employe
{
    param (
        [string]$nom,
        [string]$poste
    )
    Write-Host "Nom de l'employé : $nom"
    Write-Host "-> Poste actuel : $poste"
}

# Fonction pour adapter l'affichage d'un employé en tant que client
function Afficher-EmployeCommeClient
{
    param (
        [string]$nom,
        [string]$poste
    )
    Afficher-Employe -nom $nom -poste $poste
}

# Script principal
Afficher-Client -nom "Tom"
Afficher-EmployeCommeClient -nom "Jerry" -poste "Vendeur de fromage"
