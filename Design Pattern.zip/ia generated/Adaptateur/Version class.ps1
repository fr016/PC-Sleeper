﻿# Classe de base pour les utilisateurs
class Utilisateur
{
    [void] AfficherUtilisateur()
    {
        # Méthode de base qui peut être surchargée
    }
}

# Classe Client héritant de Utilisateur
class Client : Utilisateur
{
    [string] $_nom

    Client([string] $nom)
    {
        $this._nom = $nom
    }

    [void] AfficherUtilisateur()
    {
        Write-Host "Nom du client : $($this._nom)"
    }
}

# Classe Employe sans héritage de la classe Utilisateur
class Employe
{
    [string] $_nom
    [string] $_poste

    Employe([string] $nom, [string] $poste)
    {
        $this._nom = $nom
        $this._poste = $poste
    }

    [void] AfficherNom()
    {
        Write-Host "Nom de l'employé : $($this._nom)"
    }

    [void] AfficherPoste()
    {
        Write-Host "-> Poste actuel : $($this._poste)"
    }
}

# Classe EmployeAdapter qui adapte la classe Employe pour qu'elle se comporte comme un Utilisateur
class EmployeAdapter : Utilisateur
{
    [Employe] $_employe

    EmployeAdapter([Employe] $employe)
    {
        $this._employe = $employe
    }

    [void] AfficherUtilisateur()
    {
        $this._employe.AfficherNom()
        $this._employe.AfficherPoste()
    }
}

# Programme principal
$liste = @()
$liste += [Client]::new("Tom")
$employe = [Employe]::new("Jerry", "Vendeur de fromage")
$liste += [EmployeAdapter]::new($employe)

foreach ($utilisateur in $liste)
{
    $utilisateur.AfficherUtilisateur()
}
