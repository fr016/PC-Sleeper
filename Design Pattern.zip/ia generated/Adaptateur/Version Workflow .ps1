﻿# Définition d'un workflow pour afficher les informations d'un client
workflow Afficher-Client
{
    param (
        [string]$nom
    )
    InlineScript {
        Write-Host "Nom du client : $using:nom"
    }
}

# Définition d'un workflow pour afficher les informations d'un employé
workflow Afficher-Employe
{
    param (
        [string]$nom,
        [string]$poste
    )
    InlineScript {
        Write-Host "Nom de l'employé : $using:nom"
        Write-Host "-> Poste actuel : $using:poste"
    }
}

# Définition d'un workflow pour adapter l'affichage d'un employé en tant que client
workflow Afficher-EmployeCommeClient
{
    param (
        [string]$nom,
        [string]$poste
    )
    Afficher-Employe -nom $nom -poste $poste
}

# Exécution des workflows
Afficher-Client -nom "Tom"
Afficher-EmployeCommeClient -nom "Jerry" -poste "Vendeur de fromage"
