# Variables globales pour le cache
$cachePopular = @{}
$cacheAll = @{}

function GetVideo([string] $videoId)
 {
    if (-not $cacheAll.ContainsKey($videoId)) 
    {
        Write-Host "Downloading video..."
        Start-Sleep -Seconds 2 # Simuler la latence r�seau
        $video = New-Object PSObject -Property @{
            Id = $videoId
            Title = "Some video title"
            Data = "Random video."
        }
        $cacheAll[$videoId] = $video
    } 
    else 
    {
        Write-Host "Retrieved video '$videoId' from cache."
    }
    return $cacheAll[$videoId]
}

function GetPopularVideos() 
{
    if ($cachePopular.Count -eq 0) 
    {
        Write-Host "Downloading popular videos..."
        Start-Sleep -Seconds 2 # Simuler la latence r�seau
        # Simuler la mise en cache des vid�os populaires
        $cachePopular["popular"] = "Cached popular videos"
    } 
    else 
    {
        Write-Host "Retrieved list from cache."
    }
}

# Utilisation
$video = GetVideo "catzzzzzzzzz"
Write-Host "Video page (imagine fancy HTML)"
Write-Host "ID: $($video.Id)"
Write-Host "Title: $($video.Title)"
Write-Host "Video: $($video.Data)"
GetPopularVideos
