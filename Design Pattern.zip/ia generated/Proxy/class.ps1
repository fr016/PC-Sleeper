class Video
{
    [string] $Id
    [string] $Title
    [string] $Data

    Video([string] $id, [string] $title)
    {
        $this.Id = $id
        $this.Title = $title
        $this.Data = "Random video."
    }
}

class ThirdPartyYoutubeClass
{
    [Video] GetVideo([string] $videoId)
    {
        Write-Host "Downloading video..."
        Start-Sleep -Seconds 2 # Simuler la latence r�seau
        return [Video]::new($videoId, "Some video title")
    }

    [void] GetPopularVideos()
    {
        Write-Host "Downloading popular videos..."
        Start-Sleep -Seconds 2 # Simuler la latence r�seau
    }
}

class YoutubeCacheProxy
{
    [ThirdPartyYoutubeClass] $youtubeService
    [hashtable] $cachePopular = @{}
    [hashtable] $cacheAll = @{}

    YoutubeCacheProxy()
    {
        $this.youtubeService = [ThirdPartyYoutubeClass]::new()
    }

    [Video] GetVideo([string] $videoId)
    {
        if (-not $this.cacheAll.ContainsKey($videoId))
        {
            $this.cacheAll[$videoId] = $this.youtubeService.GetVideo($videoId)
        }
        else
        {
            Write-Host "Retrieved video '$videoId' from cache."
        }
        return $this.cacheAll[$videoId]
    }

    [void] GetPopularVideos()
    {
        if ($this.cachePopular.Count -eq 0)
        {
            $this.youtubeService.GetPopularVideos()
            # Simuler la mise en cache des vid�os populaires
            $this.cachePopular["popular"] = "Cached popular videos"
        }
        else
        {
            Write-Host "Retrieved list from cache."
        }
    }
}

# Utilisation
$proxy = [YoutubeCacheProxy]::new()
$video = $proxy.GetVideo("catzzzzzzzzz")
Write-Host "Video page (imagine fancy HTML)"
Write-Host "ID: $($video.Id)"
Write-Host "Title: $($video.Title)"
Write-Host "Video: $($video.Data)"
$proxy.GetPopularVideos()
