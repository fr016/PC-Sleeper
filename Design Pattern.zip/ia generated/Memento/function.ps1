function Create-Memento
{
    param([string]$state)
    return @{ State = $state }
}

function Get-State
{
    param([hashtable]$memento)
    return $memento.State
}

function Set-State
{
    param([ref]$originator, [string]$state)
    $originator.Value.State = $state
}

function Save-StateToMemento
{
    param([string]$state)
    return Create-Memento -state $state
}

function Get-StateFromMemento
{
    param([hashtable]$memento)
    return Get-State -memento $memento
}

function Add-Memento
{
    param([ref]$caretaker, [hashtable]$memento)
    $caretaker.Value += $memento
}

function Get-Memento
{
    param([ref]$caretaker, [int]$index)
    return $caretaker.Value[$index]
}

# Utilisation
$originator = @{}
$caretaker = @(@{})

Set-State -originator ([ref]$originator) -state "State #1"
Set-State -originator ([ref]$originator) -state "State #2"
Add-Memento -caretaker ([ref]$caretaker) -memento (Save-StateToMemento -state $originator.State)

Set-State -originator ([ref]$originator) -state "State #3"
Add-Memento -caretaker ([ref]$caretaker) -memento (Save-StateToMemento -state $originator.State)

Set-State -originator ([ref]$originator) -state "State #4"
Write-Host "Current State: $($originator.State)"

$originator.State = Get-StateFromMemento -memento (Get-Memento -caretaker ([ref]$caretaker) -index 0)
Write-Host "First saved State: $($originator.State)"

$originator.State = Get-StateFromMemento -memento (Get-Memento -caretaker ([ref]$caretaker) -index 1)
Write-Host "Second saved State: $($originator.State)"
