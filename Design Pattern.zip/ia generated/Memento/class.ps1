class Memento
{
    hidden [string] $state

    Memento([string] $state)
    {
        $this.state = $state
    }

    [string] GetState()
    {
        return $this.state
    }
}

class Originator
{
    [string] $State

    [Memento] SaveStateToMemento()
    {
        return [Memento]::new($this.State)
    }

    [void] GetStateFromMemento([Memento] $memento)
    {
        $this.State = $memento.GetState()
    }
}

class CareTaker
{
    hidden [System.Collections.ArrayList] $mementoList = @()

    [void] Add([Memento] $state)
    {
        $this.mementoList.Add($state)
    }

    [Memento] Get([int] $index)
    {
        return $this.mementoList[$index]
    }
}

# Utilisation
$originator = [Originator]::new()
$caretaker = [CareTaker]::new()

$originator.State = "State #1"
$originator.State = "State #2"
$caretaker.Add($originator.SaveStateToMemento())

$originator.State = "State #3"
$caretaker.Add($originator.SaveStateToMemento())

$originator.State = "State #4"
Write-Host "Current State: $($originator.State)"

$originator.GetStateFromMemento($caretaker.Get(0))
Write-Host "First saved State: $($originator.State)"

$originator.GetStateFromMemento($caretaker.Get(1))
Write-Host "Second saved State: $($originator.State)"
