workflow Invoke-MementoWorkflow
{
    # Initialisation des variables de workflow
    $originatorState = "State #1"
    $mementoList = @()

    InlineScript
    {
        # Fonctions pour g�rer l'�tat et les mementos
        function Create-Memento
        {
            param([string]$state)
            return @{ State = $state }
        }

        function Get-State
        {
            param([hashtable]$memento)
            return $memento.State
        }

        function Add-Memento
        {
            param([ref]$mementoList, [hashtable]$memento)
            $mementoList.Value += $memento
        }

        function Get-Memento
        {
            param([ref]$mementoList, [int]$index)
            return $mementoList.Value[$index]
        }

        # Sauvegarde de l'�tat initial
        $memento = Create-Memento -state $using:originatorState
        Add-Memento -mementoList ([ref]$using:mementoList) -memento $memento

        # Changement de l'�tat et sauvegarde du nouvel �tat
        $originatorState = "State #2"
        $memento = Create-Memento -state $using:originatorState
        Add-Memento -mementoList ([ref]$using:mementoList) -memento $memento

        # Restauration de l'�tat � partir du premier memento
        $restoredState = Get-State -memento (Get-Memento -mementoList ([ref]$using:mementoList) -index 0)
        Write-Host "Restored State: $restoredState"
    }
}

# Utilisation du workflow
Invoke-MementoWorkflow
