class Shape
{
    [void] Draw()
    {
        throw "Not implemented"
    }
}

class Circle : Shape
{
    [void] Draw()
    {
        Write-Host "Circle::draw()"
    }
}

class Rectangle : Shape
{
    [void] Draw()
    {
        Write-Host "Rectangle::draw()"
    }
}

class Square : Shape
{
    [void] Draw()
    {
        Write-Host "Square::draw()"
    }
}

class ShapeMaker
{
    [void] DrawCircle()
    {
        (New-Object Circle).Draw()
    }

    [void] DrawRectangle()
    {
        (New-Object Rectangle).Draw()
    }

    [void] DrawSquare()
    {
        (New-Object Square).Draw()
    }
}

# Utilisation de la classe ShapeMaker pour dessiner les formes
$shapeMaker = New-Object ShapeMaker
$shapeMaker.DrawCircle()
$shapeMaker.DrawRectangle()
$shapeMaker.DrawSquare()
