workflow Invoke-ShapeDrawWorkflow
{
    param([string] $shape)

    InlineScript
    {
        function Draw-Circle()
        {
            Write-Host "Circle::draw()"
        }

        function Draw-Rectangle()
        {
            Write-Host "Rectangle::draw()"
        }

        function Draw-Square()
        {
            Write-Host "Square::draw()"
        }

        switch ($using:shape)
        {
            "Circle" { Draw-Circle }
            "Rectangle" { Draw-Rectangle }
            "Square" { Draw-Square }
            default { Write-Host "Unknown shape: $using:shape" }
        }
    }
}

# Utilisation du workflow pour dessiner les formes
Invoke-ShapeDrawWorkflow -shape "Circle"
Invoke-ShapeDrawWorkflow -shape "Rectangle"
Invoke-ShapeDrawWorkflow -shape "Square"
