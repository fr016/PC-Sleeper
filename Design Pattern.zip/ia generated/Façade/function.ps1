function Draw-Circle()
{
    Write-Host "Circle::draw()"
}

function Draw-Rectangle()
{
    Write-Host "Rectangle::draw()"
}

function Draw-Square()
{
    Write-Host "Square::draw()"
}

function Draw-Shape($shape)
{
    switch ($shape)
    {
        "Circle" { Draw-Circle }
        "Rectangle" { Draw-Rectangle }
        "Square" { Draw-Square }
        default { Write-Host "Unknown shape: $shape" }
    }
}

# Utilisation des fonctions pour dessiner les formes
Draw-Shape -shape "Circle"
Draw-Shape -shape "Rectangle"
Draw-Shape -shape "Square"
