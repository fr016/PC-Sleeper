class DiscountVisitor
{
    [double] $TotalDiscount = 0

    [void] Visit([ref]$item)
    {
        if ($item.Value -is [FoodItem])
        {
            $this.TotalDiscount += $item.Value.Price * 0.3
            $item.Value.Price -= $item.Value.Price * 0.3
        }
        elseif ($item.Value -is [LiquorItem])
        {
            $this.TotalDiscount += $item.Value.Price * 0.1
            $item.Value.Price -= $item.Value.Price * 0.1
        }
    }
}

class FoodItem
{
    [int] $Id
    [string] $Name
    [double] $Price

    FoodItem([int]$id, [string]$name, [double]$price)
    {
        $this.Id = $id
        $this.Name = $name
        $this.Price = $price
    }

    [void] Apply([DiscountVisitor]$visitor)
    {
        $visitor.Visit([ref]$this)
    }
}

class LiquorItem
{
    [int] $Id
    [string] $Name
    [double] $Price

    LiquorItem([int]$id, [string]$name, [double]$price)
    {
        $this.Id = $id
        $this.Name = $name
        $this.Price = $price
    }

    [void] Apply([DiscountVisitor]$visitor)
    {
        $visitor.Visit([ref]$this)
    }
}

# Utilisation
$discountVisitor = [DiscountVisitor]::new()
$foodItem = [FoodItem]::new(1, "Italian Pizza", 6.99)
$liquorItem = [LiquorItem]::new(1, "Wine", 9.99)

$foodItem.Apply($discountVisitor)
$liquorItem.Apply($discountVisitor)

Write-Host "Total Discount = $($discountVisitor.TotalDiscount)"
