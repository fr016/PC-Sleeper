function Visit-FoodItem
{
    param([ref]$item, [ref]$totalDiscount)
    $discount = $item.Value.Price * 0.3
    $totalDiscount.Value += $discount
    $item.Value.Price -= $discount
}

function Visit-LiquorItem
{
    param([ref]$item, [ref]$totalDiscount)
    $discount = $item.Value.Price * 0.1
    $totalDiscount.Value += $discount
    $item.Value.Price -= $discount
}

# Utilisation
$totalDiscount = 0
$foodItem = @{Id=1; Name="Italian Pizza"; Price=6.99}
$liquorItem = @{Id=1; Name="Wine"; Price=9.99}

Visit-FoodItem -item ([ref]$foodItem) -totalDiscount ([ref]$totalDiscount)
Visit-LiquorItem -item ([ref]$liquorItem) -totalDiscount ([ref]$totalDiscount)

Write-Host "Total Discount = $totalDiscount"
