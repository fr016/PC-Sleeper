class NameRepository
{
    hidden [string[]] $names = @("Robert", "John", "Julie", "Lora")
    hidden [int] $index = 0

    [bool] HasNext()
    {
        return $this.index -lt $this.names.Length
    }

    [string] Next()
    {
        if ($this.HasNext())
        {
            $name = $this.names[$this.index]
            $this.index++
            return $name
        }
        return $null
    }
}

# Utilisation
$repository = [NameRepository]::new()
while ($repository.HasNext())
{
    $name = $repository.Next()
    Write-Host "Name: $name"
}
