function New-NameRepository
{
    $names = @("Robert", "John", "Julie", "Lora")
    return @{
        Names = $names
        Index = 0
    }
}

function HasNext-Name
{
    param([ref]$repository)
    return $repository.Value.Index -lt $repository.Value.Names.Length
}

function GetNext-Name
{
    param([ref]$repository)
    if (HasNext-Name -repository $repository)
    {
        $name = $repository.Value.Names[$repository.Value.Index]
        $repository.Value.Index++
        return $name
    }
    return $null
}

# Utilisation
$repository = New-NameRepository
while (HasNext-Name -repository ([ref]$repository))
{
    $name = GetNext-Name -repository ([ref]$repository)
    Write-Host "Name: $name"
}
