function CreateProductA
{
    return @{
        GetProductType = {
            return "Produit A"
        }
    }
}

function CreateProductB
{
    return @{
        GetProductType = {
            return "Produit B"
        }
    }
}

function AbstractFactory
{
    return @{
        CreateProductA = $function:CreateProductA
        CreateProductB = $function:CreateProductB
    }
}

$factory = AbstractFactory
$productA = &$factory.CreateProductA
$productB = &$factory.CreateProductB

&$productA.GetProductType # Affiche : Produit A
&$productB.GetProductType # Affiche : Produit B
