class ProductA
{
    [string] GetProductType()
    {
        return "Produit A"
    }
}

class ProductB
{
    [string] GetProductType()
    {
        return "Produit B"
    }
}

class AbstractFactory
{
    [ProductA] CreateProductA()
    {
        return [ProductA]::new()
    }

    [ProductB] CreateProductB()
    {
        return [ProductB]::new()
    }
}

$factory = [AbstractFactory]::new()
$productA = $factory.CreateProductA()
$productB = $factory.CreateProductB()

$productA.GetProductType() # Affiche : Produit A
$productB.GetProductType() # Affiche : Produit B
