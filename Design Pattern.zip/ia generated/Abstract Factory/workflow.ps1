workflow AbstractFactoryWorkflow
{
    InlineScript
    {
        function CreateProductA
        {
            return @{
                GetProductType = {
                    return "Produit A"
                }
            }
        }

        function CreateProductB
        {
            return @{
                GetProductType = {
                    return "Produit B"
                }
            }
        }

        $factory = @{
            CreateProductA = $function:CreateProductA
            CreateProductB = $function:CreateProductB
        }

        $productA = &$factory.CreateProductA
        $productB = &$factory.CreateProductB

        Write-Output (&$productA.GetProductType)
        Write-Output (&$productB.GetProductType)
    }
}

# Ex�cution du workflow
AbstractFactoryWorkflow
