﻿cls
$estAjour=$false
$currentUser=[Environment]::UserName


function MetAJour()
{
    Write-Host "Mise à Jour de Linux en cours"

    sudo apt-get update
    sudo apt-get upgrade -y
    $estAjour=$true
}
MetAJour

function CreerAlias($nomAlias,$contenuAlias)
{
    return "alias $nomAlias='$contenuAlias'"
}

function AjouteAlias()
{
    Write-Host "Ajout des alias dans le fichier .bashrc"
    cd 
    $pathFile=".bashrc"
    CreerAlias -nomAlias "update" -contenuAlias "sudo apt-get update" >> $pathFile
    CreerAlias -nomAlias "upgrade" -contenuAlias "sudo apt-get update && sudo apt-get upgrade -y" >> $pathFile
    CreerAlias -nomAlias "install" -contenuAlias "sudo apt-get install -y" >> $pathFile
    CreerAlias -nomAlias "remove" -contenuAlias "sudo apt-get remove -y --purge" >> $pathFile
}

function AjouteCronTabHebdo()
{
    echo "Ajout des Cron Tab hebdomadaire"
    $pathFile="/etc/cron.weekly/ScriptHebdomadaire.sh"
    echo "apt-get update && apt-get upgrade -y" >> $pathFile
    echo "apt-get autoremove --purge -y && apt-get autoclean -y" >> $pathFile

    chmod +x $pathFile
}

function isRoot()
{
    return $currentUser -eq "root"
}

function BuildMenu()
{
    $contenu=@"
1.ajouter les alias
2.ajouter les cron tab hebdomadaires
3.verifier la securité
4.Securiser
"@
    $choix=Read-Host $contenu

    if ($choix -eq "1")
    {
        if (isRoot)
        {
            Write-Error "pour les alias ,merci de lancer le script en tant que user normal et non en root"
        }
        else
        {
            AjouteAlias
        }
    }
    elseif ($choix -eq "2")
    {
        if (isRoot)
        {
            AjouteCronTabHebdo
        }
        else
        {
            Write-Error "pour les cron Tab ,merci de lancer le script en tant que root(sudo pwsh NomDuScript)"
        }
    }
    elseif ($choix -eq "3")
    {
        Write-Warning "Pas encore implementé"
    }
    elseif ($choix -eq "4")
    {
        Write-Warning "Pas encore implementé"
    }
    else
    {
        Write-Error "Choix non valide"
    }
}

while ($true)
{
    BuildMenu
}