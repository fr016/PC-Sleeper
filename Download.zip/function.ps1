# Fonction qui calcule le carr� d'un nombre
function Square($x)
{
    return $x * $x
}

# Fonction qui calcule le cube d'un nombre
function Cube($x)
{
    return $x * $x * $x
}

# Variable qui contient la r�f�rence � la strat�gie actuelle (par d�faut, c'est la fonction Square)
$global:currentStrategy = { param($x) $x * $x }

# Fonction qui ex�cute la strat�gie actuelle et retourne le r�sultat
function ExecuteStrategy($x)
{
    return & $global:currentStrategy $x
}

# Exemple d'utilisation de la strat�gie actuelle
$result = ExecuteStrategy 5
Write-Host "Le carr� de 5 est : $result"

# Changement de strat�gie
$global:currentStrategy = { param($x) $x * $x * $x }

# Exemple d'utilisation de la nouvelle strat�gie
$result = ExecuteStrategy 5
Write-Host "Le cube de 5 est : $result"