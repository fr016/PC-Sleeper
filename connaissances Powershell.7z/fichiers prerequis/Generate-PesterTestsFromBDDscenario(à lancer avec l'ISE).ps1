﻿param([parameter(Mandatory=$true)]$scenario)

function Generate-PesterTestsFromBDDscenario {
    
<#
ex d'utilisation:


$scenario = @"
Scenario: The file exists, and the target folder exists
    Given we have a source file
    And we have a destination folder
    When we call Copy-Item
    Then we have a new file in the destination
    And the new file is the same as the original file
"@

$tests = Generate-PesterTestsFromBDDscenario -Scenario $scenario
Write-Output $tests 

Describe 'The file exists, and the target folder exists' {         
    It 'Given we have a source file' {
        # Code de test à insérer ici
    }         
    It 'And we have a destination folder' {
        # Code de test à insérer ici
    }         
    It 'When we call Copy-Item' {
        # Code de test à insérer ici
    }         
    It 'Then we have a new file in the destination' {
        # Code de test à insérer ici
    }         
    It 'And the new file is the same as the original file' {
        # Code de test à insérer ici
    }
}
#>
    
    param (
        [string]$Scenario
    )

    # Créer un tableau de lignes en séparant le scénario en lignes
    $lines = $Scenario -split "`n"

    # Récupérer le titre du scénario
    $title = $lines[0] -replace "Scenario: ", ""

    # Créer un tableau d'étapes à partir des lignes du scénario
    $steps = $lines[1..($lines.Count - 1)]

    # Générer le code Pester pour les étapes du scénario
    $pesterCode = @"
Describe '$title' {
"@
    foreach ($step in $steps) 
    {
        $pesterCode+=@"
         
         It '$step' {
             # Code de test à insérer ici
         }

"@
}
$pesterCode+="
}"
  $pesterCode=$pesterCode.Replace("It '    ","It '")
    # Renvoyer le code Pester généré
    return $pesterCode
}

<#
 $scenario = @"
Scenario: The file exists, and the target folder exists
    Given we have a source file
    And we have a destination folder
    When we call Copy-Item
    Then we have a new file in the destination
    And the new file is the same as the original file
"@
#>


$tests = Generate-PesterTestsFromBDDscenario -Scenario $scenario
Write-Output $tests 

