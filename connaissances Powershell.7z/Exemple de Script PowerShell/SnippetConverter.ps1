﻿param ($Prod = $true)
cls
<#

convertie les snippets ISE en Snippet vscode à l'aide de https://snippet-generator.app/

How to read this Script:
1.Open it with ISE
2.CTRL + M for collapse all code regions
3.Go to "Main region" at the end of the script and click on the + for expand the region
4.Start reading the script
#>


<#
    TODO

#>

Import-Module PSLogging

#region Data
$cheminData="C:\Users\X232070\OneDrive - GROUP DIGITAL WORKPLACE\Projet\snippetConverter\data"
$urlSiteWeb="https://snippet-generator.app"
$pathSnippetISE="$cheminData\ISESnippets"
$baliseNameTabTrigger="tabTrigger"
$baliseNameTabDescription="description"
$baliseNameTabContenueISE="snippet"
$baliseVSCodeSnippet="app__pre"

$Global:Driver=$null


#endregion Data


#region Class
class SnippetVscode
{
	 [String]$TabTrigger
     [String]$Description
	 $Contenu
	
    SnippetVscode()
	{
        
	}

	SnippetVscode([String]$TabTrigger, [String]$Description,$Contenu)
	{
        $this.Description=$Description
        $this.TabTrigger=$TabTrigger
        $this.Contenu=$Contenu
	}
}

#endregion Class

#region Function

function DriverEstArrete
{
	return $Global:Driver -eq $null
}

function StopDriver ()
{
	if (!(DriverEstArrete))
	{
		Stop-SeDriver $Global:Driver
		$Global:Driver = $null
	}
}


function GetAllISESnippetNameFromCurrentSession ()
{
    @($psISE.CurrentPowerShellTab.Snippets | select DisplayTitle).DisplayTitle
}

function GetContentISESnippet ($nomSnippet)
{
    ($psISE.CurrentPowerShellTab.Snippets | where DisplayTitle -eq $nomSnippet | select CodeFragment).CodeFragment
}

function GetTabTriggerISESnippet ($nomSnippet)
{
    ($psISE.CurrentPowerShellTab.Snippets | where DisplayTitle -eq $nomSnippet | select DisplayTitle).DisplayTitle
}

function GetDescriptionISESnippet ($nomSnippet)
{
    ($psISE.CurrentPowerShellTab.Snippets | where DisplayTitle -eq $nomSnippet | select Description).Description
}



function RemplirChamp ($NomChamp, $contenuAEnvoyer, $Driver=$Global:Driver)
{

$Element = Find-SeElement -Driver $Driver -Name $NomChamp | where Displayed -eq $True

Send-SeKeys -Element $Element -Keys $contenuAEnvoyer
}

function LisChamp ($nomChamp, $Driver=$Global:Driver)
{
    $Element = Find-SeElement -Driver $Driver -Name $nomChamp
    return $Element.Text
}

function RecupereVScodeSnippetApresRemplissage ($Driver=$Global:Driver)
{
    (Find-SeElement -Driver $Driver -CssSelector ".app__pre").Text
}


function ConvertISESnippetToSnippetVscodeEtRenvoieleContenuSnippetVscode ($nomSnippet)
{
	if (DriverEstArrete)
	{
		$Global:Driver = Start-SeChrome -StartURL $urlSiteWeb
	}
	else
	{
		Enter-SeUrl -Url $urlSiteWeb -Driver $Global:Driver 
	}
   
   [SnippetVscode] $vsCodeSnippet=[SnippetVscode]::new() 
   $vsCodeSnippet.Description = GetDescriptionISESnippet -nomSnippet $nomSnippet
   $vsCodeSnippet.TabTrigger = GetTabTriggerISESnippet -nomSnippet $nomSnippet
   $vsCodeSnippet.Contenu

   RemplirChamp -NomChamp $baliseNameTabDescription -contenuAEnvoyer $vsCodeSnippet.Description
   RemplirChamp -NomChamp $baliseNameTabTrigger -contenuAEnvoyer $vsCodeSnippet.TabTrigger
   RemplirChamp -NomChamp $baliseNameTabContenueISE -contenuAEnvoyer (GetContentISESnippet -nomSnippet $nomSnippet)
   
   $vsCodeSnippet.Contenu = RecupereVScodeSnippetApresRemplissage 
   $vsCodeSnippet.Contenu = ($vsCodeSnippet.Contenu).Replace('$','$$')

   return $vsCodeSnippet.Contenu
}

function ConvertAllISESnippetToSnippetVscodeEtAjoutaFichierTexte ($path)
{
	$tabISEName = @()
	$tabISEName = GetAllISESnippetNameFromCurrentSession
    
      "{" | Out-File $path -Encoding utf8

    foreach ($item in $tabISEName)
    {
        ConvertISESnippetToSnippetVscodeEtRenvoieleContenuSnippetVscode -nomSnippet $item | Out-File $path -Append -Encoding utf8
"
,"| Out-File $path -Append -Encoding utf8
    }
   "}" | Out-File $path -Append -Encoding utf8

}

#endregion Function

#region Main

ConvertAllISESnippetToSnippetVscodeEtAjoutaFichierTexte $cheminData\powershell.json
start $cheminData\powershell.json

#endregion Main