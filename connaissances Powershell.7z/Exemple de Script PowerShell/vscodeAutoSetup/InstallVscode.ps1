param ($Prod = $true)


<#
    TODO


#>

Set-StrictMode -version Latest
#region Data Declaration

$dataPath = "C:\Users\X232070\OneDrive - GROUP DIGITAL WORKPLACE\Tuto Categorie\Systeme\Script astuces et raccourcis\PowerShell\nv fichiers\Powershell\Exemple de Script PowerShell\vscodeAutoSetup\data"
$Horodatage = "Actions du $(Get-Date -UFormat '%d-%m-%Y') à $(Get-Date -Format HH) h $(Get-Date -Format mm) min $(Get-Date -Format ss) s"
$LogPath = "$dataPath\Logs\$Horodatage.log"
$pathCred = "$dataPath\Cred"
$PathLogExcelOutput = "$dataPath\Logs\$Horodatage.xlsx"

$Domaine = @{
	'Current' = $env:USERDNSDOMAINs
}

$Cred = @{
	'MesCred' = new-object -typename System.Management.Automation.PSCredential -argumentlist ("$($Domaine.Current)\login"), (Get-Content $pathCred\mdp.txt | convertto-securestring)
}

function ChargeModule ([parameter(Mandatory = $true)]$nomModule)
{
    $res = @(Get-Module -listavailable $nomModule)
    [boolean]$moduleCharge=$false
    if ($res.Count -gt 0)
    {
        [boolean]$moduleCharge = @(Get-Module -listavailable $nomModule | Select-Object Name).name -contains $nomModule
    }
	
    if (!$moduleCharge)
    {
        Import-Module -Name $dataPath\Modules\$nomModule
    }
}

ChargeModule "Pester"
Import-Module -Name $dataPath\Modules\PSexcel
ChargeModule "PSLogging"
#endregion Data Declaration

#region Tool

Start-Log -LogPath (Split-Path $LogPath) -LogName (Split-Path $logPath -Leaf) -ScriptVersion "1.5" | Out-Null
function AfficheEtLog ($message, [ValidateSet("Info", "Warning", "Error")]$type = "Info", $ExcelLogObject = $null)
{
	if ($null -ne $ExcelLogObject)
	{
		LogActionInExcelFile -PathFileOutput $PathLogExcelOutput -ExcelLogObject $ExcelLogObject
	}
	
	if ($type -eq "Info")
	{
		Write-LogInfo -LogPath $logPath -Message $message
		Write-Output $message
		if (!$Prod) #pour qu'il s'affiche bien ds les Testes unitaires
		{
			Write-Host $message
		}
	}
	if ($type -eq "Warning")
	{
		Write-Warning $message
		Write-LogWarning -LogPath $logPath -Message $message
	}
	elseif ($type -eq "Error")
	{
		Write-Error $message

		Write-LogError -LogPath $logPath -Message $message
	}
}

<#
.SYNOPSIS
Log actions in an excel file via an ExcelLogObject Object
.EXAMPLE
    $testLogObject = [PSCustomObject]@{Action = "Add"; Objet = "User"; Complement = "GrpTest"; Resultat = "OK" }
    LogActionInExcelFile -PathFileOutput  $pathFileExcelTest -ExcelLogObject $testLogObject
#>
function LogActionInExcelFile ($PathFileOutput, $ExcelLogObject)
{
	$ExcelLogObject |  Export-XLSX -Path $PathFileOutput -AutoFit -Append
}

#Utilisez cette fonction pour initialiser/modifier un mdp stocké dur le HDD
function GereLesCredentials ()
{
    function buildQuestion($textQuestion)
    {
        $saisieQuestion = Read-Host $textQuestion "(o/n)"
	
        [boolean]$reponseCorrect = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "n" -or $saisieQuestion -eq "oui" -or $saisieQuestion -eq "non")
        [boolean]$oui = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "oui")
        [boolean]$non = ($saisieQuestion -eq "n" -or $saisieQuestion -eq "non")
	
        while (!$reponseCorrect)
        {
            Write-Host "Veuillez saisir o pour oui ou n pour non"
            $saisieQuestion = Read-Host $textQuestion "(o/n)"
            [boolean]$reponseCorrect = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "n" -or $saisieQuestion -eq "oui" -or $saisieQuestion -eq "non")
            [boolean]$reponseCorrect = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "n" -or $saisieQuestion -eq "oui" -or $saisieQuestion -eq "non")
            [boolean]$oui = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "oui")
            [boolean]$non = ($saisieQuestion -eq "n" -or $saisieQuestion -eq "non")
		
        }
	
        return $saisieQuestion
	
    }
    if (!(Test-Path -Path $pathCred))
    {
        $saisie = buildQuestion "Le dossier $pathCred n'existe pas, voulez vous le creer ?"
        if ($saisie -eq "o")
        {
            new-item -path $pathCred -type directory -Verbose
        }
    }
    else
    {
        Write-Output "Voici ce que je trouve:"
        Start-Process $pathCred
        Get-ChildItem $pathCred\*.txt | Select-Object Name
        $r = buildQuestion "Voulez vous editer un mot de passe ?"
        if ($r)
        {
            $NomFilemdp = Read-Host "Quel est le nom du fichier du mdp(ex:User)"
            read-host -assecurestring | convertfrom-securestring | out-file $pathCred\$NomFilemdp.txt -Verbose -Force
            Start-Process $pathCred
        }
    }
}

function Show-ErrorDetails
{
	param (
		$ErrorRecord = $Error[0]
	)
	
	$ErrorRecord | Format-List * -Force
	$ErrorRecord.InvocationInfo | Format-List *
	$Exception = $ErrorRecord.Exception
	for ($depth = 0; $Exception -ne $null; $depth++)
	{
		"$depth" * 80
		$Exception | Format-List -Force *
		$Exception = $Exception.InnerException
	}
}

#endregion Tool

#region Business function

#endregion Business function

#region Main

if ($prod) 
{
    Invoke-Expression "$dataPath\VSCode.exe /VERYSILENT /NORESTART /MERGETASKS=!runcode" -Verbose
}

while (!(Test-Path -Path $Env:APPDATA\Code))
{
    sleep 3
    cp $dataPath\settings.json $Env:APPDATA\Code\User -Force
    cp $dataPath\powershell.json $Env:APPDATA\Code\User\snippets -Force
}

Stop-Log -LogPath $logPath -NoExit

#endregion Main