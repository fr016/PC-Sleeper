param ($Prod = $true)

<#
# Name :  - Objective :  - Author : 
How to read this Script:
1.Open it with ISE
2.CTRL + M for collapse all code regions
3.Go to "Main region" at the end of the script and click on the + for expand the region
4.Start reading the script

-How to use this Script:
1.Ensure your credentials are saved and Encrypted on Line 71 and by call function "GereLesCredentials" below
2.Ensure Avoid spacing character in all titles ExcelFile and replace it by "_"
3.to run the script : .\NomScript.ps1 -Prod $true
#>

<#

Respecter le principe KISS
Utiliser l'existant et aller voir dabord ds notre github
Follow a simple but organized script flow:
-	#Requires comments 
-	Define your params 
-	Create your functions 
-	Setup any variables 
-	Run your code 
-	Comment based help
#>

<#
    TODO


#>

#region Tool

function global:AfficheEtLog ($message, [ValidateSet("Info", "Warning", "Error")]$type = "Info", $ExcelLogObject = $null)
{
	if ($null -ne $ExcelLogObject)
	{
		LogActionInExcelFile -PathFileOutput $PathLogExcelOutput -ExcelLogObject $ExcelLogObject
	}
	
	if ($type -eq "Info")
	{
		Write-LogInfo -LogPath $logPath -Message $message
		Write-Host $message
		if (!$Prod) #pour qu'il s'affiche bien ds les Testes unitaires
		{
			Write-Output $message
		}
	}
	if ($type -eq "Warning")
	{
		Write-Warning $message
		Write-LogWarning -LogPath $logPath -Message $message
	}
	elseif ($type -eq "Error")
	{
		Write-Error $message

		Write-LogError -LogPath $logPath -Message $message
	}
}

<#
.SYNOPSIS
Log actions in an excel file via an ExcelLogObject Object
.EXAMPLE
    $testLogObject = [PSCustomObject]@{Action = "Add"; Objet = "User"; Complement = "GrpTest"; Resultat = "OK" }
    LogActionInExcelFile -PathFileOutput  $pathFileExcelTest -ExcelLogObject $testLogObject
#>
function global:LogActionInExcelFile ($PathFileOutput, $ExcelLogObject)
{
	$ExcelLogObject  | Export-Csv -Path $PathFileOutput -Append -Delimiter ";" -Encoding UTF8 -NoTypeInformation
}

#Utilisez cette fonction pour initialiser/modifier un mdp stocké dur le HDD
function global:GereLesCredentials ()
{
    function buildQuestion($textQuestion)
    {
        $saisieQuestion = Read-Host $textQuestion "(o/n)"
	
        [boolean]$reponseCorrect = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "n" -or $saisieQuestion -eq "oui" -or $saisieQuestion -eq "non")
        [boolean]$oui = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "oui")
        [boolean]$non = ($saisieQuestion -eq "n" -or $saisieQuestion -eq "non")
	
        while (!$reponseCorrect)
        {
            Write-Host "Veuillez saisir o pour oui ou n pour non"
            $saisieQuestion = Read-Host $textQuestion "(o/n)"
            [boolean]$reponseCorrect = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "n" -or $saisieQuestion -eq "oui" -or $saisieQuestion -eq "non")
            [boolean]$reponseCorrect = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "n" -or $saisieQuestion -eq "oui" -or $saisieQuestion -eq "non")
            [boolean]$oui = ($saisieQuestion -eq "o" -or $saisieQuestion -eq "oui")
            [boolean]$non = ($saisieQuestion -eq "n" -or $saisieQuestion -eq "non")
		
        }
	
        return $saisieQuestion
	
    }
    if (!(Test-Path -Path $pathCred))
    {
        $saisie = buildQuestion "Le dossier $pathCred n'existe pas, voulez vous le creer ?"
        if ($saisie -eq "o")
        {
            new-item -path $pathCred -type directory -Verbose
        }
    }
    else
    {
        Write-Output "Voici ce que je trouve:"
        Start-Process $pathCred
        Get-ChildItem $pathCred\*.txt | Select-Object Name
        $r = buildQuestion "Voulez vous editer un mot de passe ?"
        if ($r)
        {
            $NomFilemdp = Read-Host "Quel est le nom du fichier du mdp(ex:User)"
            read-host -assecurestring | convertfrom-securestring | out-file $pathCred\$NomFilemdp.txt -Verbose -Force
            Start-Process $pathCred
        }
    }
}

function global:Show-ErrorDetails
{
	param (
		$ErrorRecord = $Error[0]
	)
	
	$ErrorRecord | Format-List * -Force
	$ErrorRecord.InvocationInfo | Format-List *
	$Exception = $ErrorRecord.Exception
	for ($depth = 0; $Exception -ne $null; $depth++)
	{
		"$depth" * 80
		$Exception | Format-List -Force *
		$Exception = $Exception.InnerException
	}
}

#endregion Tool