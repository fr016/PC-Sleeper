param ($Prod = $true)

<#
# Name :  - Objective :  - Author : 
How to read this Script:
1.Open it with ISE
2.CTRL + M for collapse all code regions
3.Go to "Main region" at the end of the script and click on the + for expand the region
4.Start reading the script

-How to use this Script:
1.Ensure your credentials are saved and Encrypted on Line 71 and by call function "GereLesCredentials" below
2.Ensure Avoid spacing character in all titles ExcelFile and replace it by "_"
3.to run the script : .\NomScript.ps1 -Prod $true
#>

<#

Respecter le principe KISS
Utiliser l'existant et aller voir dabord ds notre github
Follow a simple but organized script flow:
-	#Requires comments 
-	Define your params 
-	Create your functions 
-	Setup any variables 
-	Run your code 
-	Comment based help
#>

<#
    TODO


#>

#region Tool
Set-Alias -name gusr -value GetADUserTrustIncluded

function global:GetADUserTrustIncluded
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
        [string]$Identity,
        [string]$Properties = ""
    )
    $user = $null
    $domains = @($env:USERDNSDOMAIN.ToLower())
    $domains += (Get-ADTrust -Filter *).Name

    Write-Verbose "search for user $Identity in current domain($env:USERDNSDOMAIN) and in trusted domains"

    foreach ($domain in $domains)
    {
        try
        {
            if ($Properties -eq "")
            {
                $user = Get-ADUser $Identity -Server $domain
            }
            else
            {
                $user = Get-ADUser $Identity -Server $domain -Properties $Properties
            }
            Write-Verbose "The user $Identity was found on the domain $domain"
            break
        }
        catch
        {
            Write-Verbose "The user $Identity was not found on the domain $domain"
        }
    }

    if ($user -eq $null)
    {
        throw "$user was not found in the current domain ($env:USERDNSDOMAIN) nor in the trusted domains"
    }
    
    return $user
}

Set-Alias -name ggrp -value GetADGroupTrustIncluded

function global:GetADGroupTrustIncluded
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, ValueFromPipelineByPropertyName = $true)]
        [string]$Identity,
        [string]$Properties = ""
    )
    $grp = $null
    $domains = @($env:USERDNSDOMAIN.ToLower())
    $domains += (Get-ADTrust -Filter *).Name

    Write-Verbose "search for the group $Identity in the current domain($env:USERDNSDOMAIN) and in the trusted domains"

    foreach ($domain in $domains)
    {
        try
        {
            if ($Properties -eq "")
            {
                $grp = Get-ADGroup $Identity -Server $domain
            }
            else
            {
                $grp = Get-ADGroup $Identity -Server $domain -Properties $Properties
            }
            Write-Verbose "The group $Identity was found on the domain $domain"
            break
        }
        catch
        {
            Write-Verbose "The group $Identity was not found on the domain $domain"
        }
    }

    if ($grp -eq $null)
    {
        throw "$grp was not found in the current domain ($env:USERDNSDOMAIN) nor in the trusted domains"
    }
    
    return $grp
}

#can add users but also GS in GS
Set-Alias -name AjouteDsGrpDeSecurite -value AddInSecurityGrp
function global:AddInSecurityGrp
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$GrpName,
        [Parameter(Mandatory = $true)]
        [string]$Sam,
        [string]$DomainName = $env:USERDNSDOMAIN,
        [PSCredential]$Cred
    )

    LogAndDisplay "Ajout de $Sam dans $GrpName"
        
    $userToAdd = GetADUserTrustIncluded $Sam
    if ($DomainName -eq $env:USERDNSDOMAIN)
    {
        Add-ADGroupMember $GrpName -Members $userToAdd
    }
    else
    {
        Add-ADGroupMember $GrpName -Members $userToAdd -Server $DomainName -Credential $Cred 
    }
}


Set-Alias -name GroupADExist -value ADGroupExist
function global:ADGroupExist ([String]$GrpName, [String]$DomainShortName = $env:USERDOMAIN, [Hashtable]$DomainProvider)
{
    if ($DomainShortName -eq $env:USERDOMAIN)
    {
        try
        {
            Get-ADGroup -Identity $GrpName | Out-Null
        }
        catch
        {
            return $false
        }
    }
    else
    {
        try
        {
            Get-ADGroup -Identity $GrpName -Server ($DomainProvider).($DomainShortName).FQDN -Credential ($DomainProvider).($DomainShortName).Cred | Out-Null
        }
        catch
        {
            return $false
        }
    }
    return $true
}

function global:SIDToSam ()
{
    <#
    .SYNOPSIS
    Converts a SID to a SAM account name.
    
    .DESCRIPTION
    The SIDToSam function takes a SID (Security Identifier) as a parameter, and converts it 
    to a SAM account name using the System.Security.Principal.SecurityIdentifier and System.Security.Principal.NTAccount classes. It returns the account name as a string. 
    If the conversion fails, it throws an error with the message "Failed to convert SID to SAM account name: $_"

    .PARAMETER SID
    The SID to convert to a SAM account name.
    
    .EXAMPLE
    PS C:\> SIDToSam -SID "S-1-5-21-3165297888-301567370-576410423-1103"
    "DOMAIN\Username"
#>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$SID
    )

    try
    {
        $tmp = New-Object System.Security.Principal.SecurityIdentifier($SID)
        $account = $tmp.Translate([System.Security.Principal.NTAccount])
        return $account.Value
    }
    catch
    {
        LogAndDisplay -message "Failed to convert SID $SID to SAM account name: $_ 
        (does the associated user account still exist?)" -type Warning
    }
}

function global:CNToSam ()
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$CN
    )

    <#
    .SYNOPSIS
    Converts a CN (Common Name) to a SAM account name.
    
    .DESCRIPTION
    The CNToSam function takes a CN (Common Name) and an optional parameter for a target domain as input. It first checks if the CN is for a foreign security principal or has a SID format. If so, it uses the SIDToSam function to convert the SID to a SAM account name and returns it. If not, it uses the Get-ADUser cmdlet to retrieve the UserPrincipalName of the user, and constructs the SAM account name in the format "domainShortName\sam" and returns it. If the user is not found, it throws an error with the message "User not found: $CN".

    .PARAMETER CN
    The CN to convert to a SAM account name.
    
    .PARAMETER DomCible
    The target domain to use. Default is the current user's domain.
    
    .EXAMPLE
    PS C:\> CNToSam -CN "CN=John Doe,OU=Users,DC=example,DC=com"
    "EXAMPLE\johndoe"
#>
    $res = $null
    Write-Verbose "CN $CN conversion in progress"
    if ($CN -notmatch $env:USERDOMAIN -or (Select-String -Pattern 'S-\d-(?:\d+-){1,14}\d+' -InputObject $CN))
    {
        if ($CN -match "CN=ForeignSecurityPrincipals" -or (Select-String -Pattern 'S-\d-(?:\d+-){1,14}\d+' -InputObject $CN))
        {
            Write-Verbose "ForeignSecurityPrincipals ou SID detecte dans le CN"
        
            $SID = ($CN.split('=')[1]).split(',')[0]
            $res = SIDToSam -SID $SID 
        }
        else 
        {
            Write-Verbose "$env:USERDOMAIN not present in CN"
        
            $sam = ($CN.split('=')[1]).split(',')[0]
            $res = $sam
        }
    }
    else
    {
        $user = GetADUserTrustIncluded -Identity $CN 
        if ($null -ne $user)
        {
            $res = SIDToSam $user.SID
        }
        else
        {
            $res = SIDToSam $grp.SID
        }
    }
    return $res
}

Set-Alias -name MembresDuGroupAD -value MembersOfTheADGroup
function global:MembersOfTheADGroup ()
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$GrpName,
        [String]$DomainShortName = $env:USERDOMAIN,
        [parameter(Mandatory = $true)][Hashtable]$DomainProvider = $null
    )
    
    <#
    .SYNOPSIS
    Retrieves the members of an AD group and converts their CNs to SAM account names.
    
    .DESCRIPTION
    The MembersOfTheADGroup function takes as input a group name, a short domain name and a domain provider. 
    It first retrieves the group members from Active Directory using the Get-ADGroup cmdlet. 
    If the short domain name is that of the current user, it will use the credentials of the current user, otherwise it will use the credentials
    provided in the domain provider parameter. Then it converts the CN of each member to a SAM account name using the CNToSam function. If an ADIdentityNotFoundException is caught, 
    it builds the SAM account name using the UserPrincipalName. It returns an array of SAM account names.

    .PARAMETER NameGS
    The name of the AD group to retrieve members.
    
    .PARAMETER DomainShortName
    The short name of the domain to use. By default, this is the domain of the current user.
    
    .PARAMETER DomainProvider
    A hashtable containing the FQDN and credentials for the domain to use.
    
    .EXAMPLE
    PS C:\> MembersOfTheADGroup -NomGS "Marketing Team" -DomainShortName "DomainName" -DomainProvider $domainProvider
    "EURJohnDoe", "EURJaneDoe"
    #>
    
    $res = New-Object "System.Collections.Generic.List[String]"
    $ListeCN = New-Object "System.Collections.Generic.List[String]"
    $properties = @("Member", "UserPrincipalName")

    LogAndDisplay "Extracting AD group $DomainShortName\$GrpName in progress"

    if ($DomainShortName -eq $env:USERDOMAIN)
    {
        $ListeCN = @(Get-ADGroup $GrpName -Properties $properties | Select-Object -Expand Member)
    }
    else
    {
        $ListeCN = @(Get-ADGroup $GrpName  -Server ($DomainProvider).($DomainShortName).FQDN -Credential ($DomainProvider).($DomainShortName).Cred -Properties $properties | Select-Object -Expand Member)
    }

    Write-Verbose "CN Conversion"

    foreach ($CN in $ListeCN)
    {
        try
        {
            Write-Verbose "CN $CN in progress"
            
            $res.Add((CNToSam -CN $CN))              
        }
        catch [Microsoft.ActiveDirectory.Management.ADIdentityNotFoundException]
        {
            Write-Verbose "2nd attempt to convert $CN to sam"
            $UPN = (Get-ADUser -Identity $CN -Properties $properties -Server ($DomainProvider).($DomainShortName).FQDN -Credential ($DomainProvider).($DomainShortName).Cred).UserPrincipalName
        
            $domFQDN = $UPN.split("@")[1]
            $domShortname = $domFQDN.split(".")[0]
            $domShortname = $domShortname.ToUpper()

            $sam = $UPN.split("@")[0]
            $res.Add("$domShortname\$sam")
        }
    }
    
    LogAndDisplay "$($res.Count) members found"
    return $res
}

Set-Alias -name Test-ADUser -value UserExist
function global:UserExist()
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$SAMAccountName,
        [String]$DomainFQDN = "",
        [PSCredential] $Cred
    )

    $res = $null
    if ($DomainFQDN -eq "")
    {
        LogAndDisplay "Check if $SAMAccountName exists on $env:USERDOMAIN"
        
        $res = ([ADSISearcher] "(SAMAccountName=$SAMAccountName)").FindOne()
    }
    else
    {
        LogAndDisplay "Check if $SAMAccountName exists on $($DomainFQDN.Split(".")[0].ToUpper())"
        
        $res = Get-ADUser -Server $DomainFQDN -Filter { SAMAccountName -eq $SAMAccountName } -Credential $Cred
    }
	 
    return $null -ne $res 
}

Set-Alias -Name "AfficheGroupesADFromUser" -Value ExtractGrpFromUser
function global:ExtractGrpFromUser()
{
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$SamUser,
        [String]$DomainShortName = $env:USERDOMAIN,
        [Hashtable]$DomainProvider = $null
    )

    LogAndDisplay -message "Extraction of AD groups from $($DomainShortName+"\"+$Samuser) in progress"

    $res = @()
    
    if ($DomainShortName -eq $env:USERDOMAIN)
    {
        Write-Verbose "the user is in the current domain ($DomainShortName)"
        $ListeCN = Get-ADUser $SamUser -Properties MemberOf | Select-Object -exp MemberOf
    }
    else
    {
        Write-Verbose "the user is in another domain ($DomainShortName)"
        
        $ListeCN = Get-ADUser $SamUser -Properties MemberOf -Server $DomainShortName -Credential $DomainProvider.$($DomainShortName).Cred | Select-Object -exp MemberOf
    }
    
    foreach ($CN in $ListeCN)
    {
        $content = ""
        
        try
        {
            $content = (GetADGroupTrustIncluded -Identity $CN).name        
        }
        catch [Microsoft.ActiveDirectory.Management.ADIdentityNotFoundException]
        {
            $content = (Get-ADGroup $CN -Server $DomainShortName -Credential $DomainProvider.$($DomainShortName).Cred).name             
        }

        $res += "$content"
    }

    return $res 
}

Set-Alias -name estDsGrpAD -value isInADGrp
function global:isInADGrp ()
{
    [CmdletBinding()]
    param (
        [ValidateNotNullOrEmpty()]
        [parameter(Mandatory = $true)]$samUser, 
        [ValidateNotNullOrEmpty()]
        [parameter(Mandatory = $true)][String]$GrpName, 
        [String]$DomainShortName = $env:USERDOMAIN,
        [Hashtable]$DomainProvider
    )
    
    $GrpName = $GrpName.ToLower()
    if ($GrpName.Contains("\"))
    {
        $GrpName = $GrpName.Split("\")[1]
    }

    LogAndDisplay "Check if $($DomainShortName+'\'+$samUser) is in AD group $GrpName"

    $UserMembersOf = ""
    $userDansDomaineCourant = UserExist -SAMAccountName $samUser
    if ($DomainShortName -eq $env:USERDOMAIN)
    {
        Write-Verbose "$GrpName is in the current domain"
        if ($userDansDomaineCourant)
        {
            Write-Verbose "$samUser is in the current domain"
            
            $UserMembersOf = (Get-ADUser $samUser -Properties memberof | select -exp memberof)
            Write-Verbose "Finding group name $GrpName in memberOf of $samUser"
        
            foreach ($item in $UserMembersOf)
            {
                Write-Verbose "CN in progress : $item"
        
                if ($item -match $GrpName)
                {
                    Write-Verbose "$GrpName found in $item"
            
                    return $true
                }
            }
            Write-Verbose "No match found"

            return $false
        }
        else
        {
            Write-Verbose "$samUser is a Trusted account"
            
            try
            {
                $res = (MembersOfTheADGroup $GrpName -DomainProvider $DomainProvider -DomainShortName $DomainShortName) | Where-Object { $_ -match $samUser }

                if ($res.Contains("\"))
                {
                    $res = $res.split("\")[1] 
                }
                return ($res -eq $samUser)
            }
            catch [System.Management.Automation.RuntimeException]
            {
                return $false
            }
        }
    }
    else
    {
        Write-Verbose "the group is in another domain"
        if (!$userDansDomaineCourant)
        {
            Write-Verbose "$samUser is in another domain"
        }
        
        try
        {
            $res = (MembersOfTheADGroup $GrpName -DomainProvider $DomainProvider -DomainShortName $DomainShortName) | Where-Object { $_ -match $samUser }

            if ($res.Contains("\"))
            {
                $res = $res.split("\")[1] 
            }
            return ($res -eq $samUser)
        }
        catch [System.Management.Automation.RuntimeException]
        {
            return $false
        }

        #reminder: we cannot go through the member of because it does not appear for truste groups
    }
}

Set-Alias -name Log -value LogAndDisplay
function global:LogAndDisplay ($message, [ValidateSet("Info", "Warning", "Error")]$type = "Info", $ExcelLogObject = $null)
{
    if ($null -ne $ExcelLogObject)
    {
        LogActionInExcelFile -PathFileOutput $PathLogExcelOutput -ExcelLogObject $ExcelLogObject
    }
	
    if ($type -eq "Info")
    {
        Write-LogInfo -LogPath $logPath -Message $message
        Write-Host $message
    }
    if ($type -eq "Warning")
    {
        Write-Warning $message
        Write-LogWarning -LogPath $logPath -Message $message
    }
    elseif ($type -eq "Error")
    {
        Write-Error $message

        Write-LogError -LogPath $logPath -Message $message
    }
}

<#
.SYNOPSIS
Log actions in an excel file via an ExcelLogObject Object
.EXAMPLE
    $testLogObject = [PSCustomObject]@{Action = "Add"; Objet = "User"; Complement = "GrpTest"; Resultat = "OK" }
    LogActionInExcelFile -PathFileOutput  $pathFileExcelTest -ExcelLogObject $testLogObject
#>
function global:LogActionInExcelFile ($PathFileOutput, $ExcelLogObject)
{
    LogAndDisplay "Adding the line $ExcelLogObject in the Excel log"
    $ExcelLogObject  | Export-Csv -Path $PathFileOutput -Append -Delimiter ";" -Encoding UTF8 -NoTypeInformation
}

#Use this function to initialize/modify a password stored on the HDD
Set-Alias -name GereLesCredentials -value ManageCredentials
function global:ManageCredentials ()
{
    function buildQuestion($textQuestion)
    {
        $inputQuestion = Read-Host $textQuestion "(y/n)"
	
        [boolean]$correctAnswer = ($inputQuestion -eq "y" -or $inputQuestion -eq "n" -or $inputQuestion -eq "yes" -or $inputQuestion -eq "no")
        [boolean]$yes = ($inputQuestion -eq "y" -or $inputQuestion -eq "yes")
        [boolean]$no = ($inputQuestion -eq "n" -or $inputQuestion -eq "no")
	
        while (!$correctAnswer)
        {
            Write-Host "Please enter y for yes or n for no"
            $inputQuestion = Read-Host $textQuestion "(y/n)"
            [boolean]$correctAnswer = ($inputQuestion -eq "y" -or $inputQuestion -eq "n" -or $inputQuestion -eq "yes" -or $inputQuestion -eq "no")
            [boolean]$correctAnswer = ($inputQuestion -eq "y" -or $inputQuestion -eq "n" -or $inputQuestion -eq "yes" -or $inputQuestion -eq "no")
            [boolean]$yes = ($inputQuestion -eq "y" -or $inputQuestion -eq "yes")
            [boolean]$no = ($inputQuestion -eq "n" -or $inputQuestion -eq "no")
		
        }
	
        return $inputQuestion
	
    }
    if (!(Test-Path -Path $pathCred))
    {
        $saisie = buildQuestion "The folder $pathCred does not exist, do you want to create it?"
        if ($saisie -eq "y")
        {
            new-item -path $pathCred -type directory -Verbose
        }
    }
    else
    {
        Write-Output "Here is what I find :"
        Start-Process $pathCred
        Get-ChildItem $pathCred\*.txt | Select-Object Name
        $FileNamePassword = Read-Host "What is the name of the mdp file (ex:User)"
        read-host -assecurestring | convertfrom-securestring | out-file $pathCred\$FileNamePassword.txt -Verbose -Force
        Start-Process $pathCred
    }
}

function global:Show-ErrorDetails
{
    param (
        $ErrorRecord = $Error[0]
    )
	
    $ErrorRecord | Format-List * -Force
    $ErrorRecord.InvocationInfo | Format-List *
    $Exception = $ErrorRecord.Exception
    for ($depth = 0; $Exception -ne $null; $depth++)
    {
        "$depth" * 80
        $Exception | Format-List -Force *
        $Exception = $Exception.InnerException
    }
}

Function global:SendMail
{
    param(
        [parameter(Mandatory = $True)][string]$Sender, 
        [parameter(Mandatory = $True)][string]$Receiver,
        [parameter(Mandatory = $False)][string]$CC,
        [parameter(Mandatory = $True)][string]$Subject, 
        [parameter(Mandatory = $True)][string]$Body,
        [parameter(Mandatory = $False)][switch]$IsBodyHTML,
        [parameter(Mandatory = $False)][array]$Attachment,
        [parameter(Mandatory = $True)][string]$SmtpServerName,
        [parameter(Mandatory = $True)][ipaddress]$SmtpServerIP
    )

    $Message = New-Object system.Net.Mail.MailMessage
    $Message.IsBodyHTML = $IsBodyHTML.IsPresent
    $Message.body = $Body
    $Message.From = $Sender
    $Message.subject = $Subject
    $Message.to.add($Receiver)
    if ($CC)
    {
        $Message.CC.add($CC)
    }
    if ($Attachment)
    { 
        foreach ($Attach in $Attachment)
        {
            cp $Attach $env:TMP -Force

            $message.Attachments.Add((Join-Path -Path ($env:TMP) -ChildPath $(Split-Path -Path $Attach -Leaf)))
        }
    }

    $Client = New-Object system.Net.Mail.SmtpClient
    if (Test-Connection ($SmtpServerName)) { $Client.set_host($SmtpServerIP) }
    else { $Client.set_host($SmtpServerIP) }
    $Client.send($Message)
}

#endregion Tool