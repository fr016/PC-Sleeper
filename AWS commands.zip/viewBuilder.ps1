function Generate-HTMLReport {
    param (
        [Parameter(Mandatory=$true)]
        [string]$OutputFilePath,

        [Parameter(Mandatory=$true)]
        [string]$TemplatePath,

        [Parameter(Mandatory=$true)]
        [array]$BucketData
    )

    $htmlTemplate = Get-Content -Raw -Path $TemplatePath
    $dataRows = Generate-HTMLDataRows $BucketData
    $htmlContent = Replace-HTMLTags $htmlTemplate $dataRows
    Save-HTMLToFile $OutputFilePath $htmlContent
}

function Generate-HTMLDataRows {
    param (
        [Parameter(Mandatory=$true)]
        [array]$BucketData
    )

    $rows = foreach ($bucket in $BucketData) {
        "<tr><td>$($bucket.BucketName)</td><td class='used-space'>$($bucket.UsedSpace) GB</td><td>$($bucket.Threshold) GB</td></tr>"
    }

    $rows -join [System.Environment]::NewLine
}

function Replace-HTMLTags {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Template,

        [Parameter(Mandatory=$true)]
        [string]$DataRows
    )

    $templateWithRows = $Template -replace '##DATA_ROWS##', $DataRows
    $templateWithRows
}

function Save-HTMLToFile {
    param (
        [Parameter(Mandatory=$true)]
        [string]$FilePath,

        [Parameter(Mandatory=$true)]
        [string]$HTMLContent
    )

    $HTMLContent | Out-File -FilePath $FilePath -Encoding UTF8
}

$bucketData = @(
    @{
        BucketName = "Bucket1"
        UsedSpace = 25
        Threshold = 20
    },
    @{
        BucketName = "Bucket2"
        UsedSpace = 19
        Threshold = 20
    }
)

$templatePath = "template.html"
$outputFilePath = "PowerShellReport.html"

Generate-HTMLReport -OutputFilePath $outputFilePath -TemplatePath $templatePath -BucketData $bucketData
