# Installez le module AWS PowerShell s'il n'est pas d�j� install�
# Install-Module -Name AWSPowerShell -Force -AllowClobber

# Importez le module AWS PowerShell
Import-Module AWSPowerShell

# Configurez vos informations d'identification AWS (Access Key et Secret Key)
$accessKey = "YourAccessKey"
$secretKey = "YourSecretKey"
$region = "YourAWSRegion"

# Configurez les informations d'identification AWS
Set-AWSCredentials -AccessKey $accessKey -SecretKey $secretKey -StoreAs "MyCredentials"

# Configurez la r�gion AWS
Set-DefaultAWSRegion -Region $region

# Obtenez la liste des buckets S3
$bucketList = Get-S3Bucket

# Construisez les donn�es des buckets
$bucketData = foreach ($bucket in $bucketList) {
    $bucketInfo = @{
        BucketName = $bucket.BucketName
        UsedSpace = (Get-S3BucketStatistics -BucketName $bucket.BucketName).SizeInBytes / 1GB  # Convertir en Go
        Threshold = 20  # Vous devrez d�finir votre propre seuil ici
    }
    New-Object PSObject -Property $bucketInfo
}

# Exemple d'affichage des donn�es des buckets
$bucketData | Format-Table -AutoSize

# Exemple d'utilisation de la fonction Generate-HTMLReport avec les donn�es des buckets
$templatePath = "template.html"
$outputFilePath = "PowerShellReport.html"

Generate-HTMLReport -OutputFilePath $outputFilePath -TemplatePath $templatePath -BucketData $bucketData


<#
 OU BIEN
#>



# Installez le module AWS PowerShell s'il n'est pas d�j� install�
# Install-Module -Name AWSPowerShell -Force -AllowClobber

# Importez le module AWS PowerShell
Import-Module AWSPowerShell

# Configurez vos informations d'identification AWS (Access Key et Secret Key)
$accessKey = "YourAccessKey"
$secretKey = "YourSecretKey"
$region = "YourAWSRegion"

# Configurez les informations d'identification AWS
Set-AWSCredentials -AccessKey $accessKey -SecretKey $secretKey -StoreAs "MyCredentials"

# Configurez la r�gion AWS
Set-DefaultAWSRegion -Region $region

# Obtenez la liste des buckets S3
$bucketList = Get-S3Bucket

# Construisez les donn�es des buckets
$bucketData = foreach ($bucket in $bucketList) {
    $bucketInfo = @{
        BucketName = $bucket.BucketName
        UsedSpace = (Get-S3BucketStatistics -BucketName $bucket.BucketName).SizeInBytes / 1GB  # Convertir en Go
        Threshold = 20  # Vous devrez d�finir votre propre seuil ici
    }
    New-Object PSObject -Property $bucketInfo
}

# Exemple d'affichage des donn�es des buckets
$bucketData | Format-Table -AutoSize

# Exemple d'utilisation de la fonction Generate-HTMLReport avec les donn�es des buckets
$templatePath = "template.html"
$outputFilePath = "PowerShellReport.html"

Generate-HTMLReport -OutputFilePath $outputFilePath -TemplatePath $templatePath -BucketData $bucketData
