# Import du module
Import-Module .\MySQLUtils.psm1

# Connexion
Connect-MySQL -Server "127.0.0.1" -User "root" -Password "mon_mdp" -Database "test_db"

# Insertion
Insert-MySQL -Table "users" -Data @{name="John"; age=30}

# S�lection
$users = Select-MySQL -Table "users"
$users | Format-Table

# Mise � jour
Update-MySQL -Table "users" -Data @{age=31} -Where "name='John'"

# Suppression
Delete-MySQL -Table "users" -Where "name='John'"

# Fermeture de connexion
Disconnect-MySQL