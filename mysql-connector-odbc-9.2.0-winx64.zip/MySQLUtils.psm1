# Chargement du connecteur MySQL
[void] [System.Reflection.Assembly]::LoadWithPartialName("MySql.Data")

# Variables globales pour la connexion
$global:MySQL_Connection = $null

# Fonction de logging
function Write-Log {
    param (
        [string]$Message,
        [string]$LogFile = "C:\Logs\MySQL_PowerShell.log"
    )
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$Timestamp - $Message" | Out-File -Append -FilePath $LogFile
}

<# 
.SYNOPSIS
    Etablit une connexion à la base de données MySQL
.DESCRIPTION
    Initialise la connexion MySQL et la stocke dans une variable globale.
.PARAMETER Server
    Adresse du serveur MySQL
.PARAMETER Port
    Port MySQL (3306 par défaut)
.PARAMETER User
    Nom d'utilisateur MySQL
.PARAMETER Password
    Mot de passe MySQL
.PARAMETER Database
    Nom de la base de données à utiliser
#>
function Connect-MySQL {
    param (
        [string]$Server = "127.0.0.1",
        [int]$Port = 3306,
        [string]$User = "root",
        [string]$Password = "password",
        [string]$Database = "test_db"
    )

    try {
        $global:MySQL_Connection = New-Object MySql.Data.MySqlClient.MySqlConnection("server=$Server;port=$Port;uid=$User;pwd=$Password;database=$Database;Pooling=False")
        $global:MySQL_Connection.Open()
        Write-Log "Connexion réussie à MySQL ($Server:$Port - DB: $Database)"
    } catch {
        Write-Log "Erreur de connexion à MySQL : $_"
        throw $_
    }
}

<# 
.SYNOPSIS
    Ferme proprement la connexion MySQL
#>
function Disconnect-MySQL {
    if ($global:MySQL_Connection -ne $null) {
        $global:MySQL_Connection.Close()
        $global:MySQL_Connection.Dispose()
        $global:MySQL_Connection = $null
        Write-Log "Connexion MySQL fermée proprement."
    }
}

<# 
.SYNOPSIS
    Exécute une requête SQL et retourne les résultats
.PARAMETER Query
    Requête SQL à exécuter
#>
function Execute-MySQLQuery {
    param (
        [string]$Query
    )

    try {
        if ($global:MySQL_Connection -eq $null) {
            throw "La connexion MySQL n'est pas ouverte. Exécutez Connect-MySQL d'abord."
        }

        $Command = New-Object MySql.Data.MySqlClient.MySqlCommand($Query, $global:MySQL_Connection)
        $Adapter = New-Object MySql.Data.MySqlClient.MySqlDataAdapter($Command)
        $DataSet = New-Object System.Data.DataSet
        $Adapter.Fill($DataSet) | Out-Null

        Write-Log "Requête exécutée : $Query"
        return $DataSet.Tables[0]
    } catch {
        Write-Log "Erreur lors de l'exécution de la requête : $_"
        throw $_
    }
}

<# 
.SYNOPSIS
    Insère des données dans une table MySQL
.PARAMETER Table
    Nom de la table où insérer les données
.PARAMETER Data
    Hashtable contenant les colonnes et valeurs à insérer
#>
function Insert-MySQL {
    param (
        [string]$Table,
        [hashtable]$Data
    )

    $Columns = ($Data.Keys -join ", ")
    $Values = ($Data.Values | ForEach-Object { "'$_'" }) -join ", "
    $Query = "INSERT INTO $Table ($Columns) VALUES ($Values);"

    Execute-MySQLQuery -Query $Query | Out-Null
    Write-Log "Insertion dans $Table : $Query"
}

<# 
.SYNOPSIS
    Sélectionne des données depuis une table MySQL
.PARAMETER Table
    Nom de la table
.PARAMETER Where
    Condition WHERE optionnelle
#>
function Select-MySQL {
    param (
        [string]$Table,
        [string]$Where = $null
    )

    $Query = "SELECT * FROM $Table"
    if ($Where) { $Query += " WHERE $Where" }

    return Execute-MySQLQuery -Query $Query
}

<# 
.SYNOPSIS
    Met à jour des données dans une table MySQL
.PARAMETER Table
    Nom de la table
.PARAMETER Data
    Hashtable des colonnes à mettre à jour
.PARAMETER Where
    Condition WHERE
#>
function Update-MySQL {
    param (
        [string]$Table,
        [hashtable]$Data,
        [string]$Where
    )

    $SetValues = ($Data.Keys | ForEach-Object { "$_ = '$($Data[$_])'" }) -join ", "
    $Query = "UPDATE $Table SET $SetValues WHERE $Where;"

    Execute-MySQLQuery -Query $Query | Out-Null
    Write-Log "Mise à jour dans $Table : $Query"
}

<# 
.SYNOPSIS
    Supprime des données d'une table MySQL
.PARAMETER Table
    Nom de la table
.PARAMETER Where
    Condition WHERE
#>
function Delete-MySQL {
    param (
        [string]$Table,
        [string]$Where
    )

    $Query = "DELETE FROM $Table WHERE $Where;"
    Execute-MySQLQuery -Query $Query | Out-Null
    Write-Log "Suppression dans $Table : $Query"
}
